# Communication Center Display

Minimal GitHub Pages dashboard for a single TV.

## Display
- Large 24-hour clock and date
- YouTube information feed
- Current NWS conditions
- Wind, humidity, sunrise, and sunset
- Department notice queue
- Active NWS alerts
- Compact integrated status indicator

Weather icons are built into `index.html` as minimal inline SVG graphics. No separate icon files are required.

## Updates
Edit `config.json` and commit the change. The display checks for configuration updates every 30 seconds.
